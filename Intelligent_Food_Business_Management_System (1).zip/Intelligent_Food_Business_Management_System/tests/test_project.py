import sys
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.data_utils import clean_data
from utils.ml_models import train_models, predict_sales, predict_inventory, predict_waste
from utils.nlp_models import train_sentiment_model, predict_sentiment

def test_data_cleaning():
    df = pd.read_csv(ROOT / "data" / "restaurant_business_dataset.csv")
    cleaned = clean_data(df)
    assert len(cleaned) > 0
    assert cleaned["Total_Sales"].notna().all()

def test_models():
    df = clean_data(pd.read_csv(ROOT / "data" / "restaurant_business_dataset.csv"))
    models = train_models(df)
    row = df.iloc[0]
    assert predict_sales(models["sales"], row.Menu_Item, row.Category, row.Branch, row.Day_of_Week, int(row.Month), 3, float(row.Unit_Price)) >= 0
    assert predict_inventory(models["inventory"], row.Menu_Item, row.Category, row.Branch, row.Day_of_Week, int(row.Month), 3, float(row.Unit_Price), 20) >= 0
    assert predict_waste(models["waste"], row.Menu_Item, row.Category, row.Branch, row.Day_of_Week, int(row.Month), 3, float(row.Unit_Price), 20) >= 0

def test_sentiment():
    df = clean_data(pd.read_csv(ROOT / "data" / "restaurant_business_dataset.csv"))
    model = train_sentiment_model(df)
    label, confidence = predict_sentiment(model, "Very tasty and fresh")
    assert label in {"Positive", "Negative", "Neutral"}
    assert 0 <= confidence <= 1
